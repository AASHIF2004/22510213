
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const url = new URL(request.url);
  const minutes = url.searchParams.get('minutes') || '5';

  // Replace with your actual test server API
  const apiUrl = `http://20.244.56.144/evaluation-service/stock-prices?minutes=${minutes}`;

  try {
    const res = await fetch(apiUrl, {
      headers: {
        'Content-Type': 'application/json',
        // include auth headers if needed
      }
    });

    if (!res.ok) throw new Error('Test server error');
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json({ error: 'Failed to fetch stock prices' }, { status: 500 });
  }
}