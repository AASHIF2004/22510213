// app/heatmap/page.tsx
'use client';

import { useEffect, useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  CircularProgress,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Tooltip as MuiTooltip
} from '@mui/material';
import { ResponsiveHeatMap } from '@nivo/heatmap';

interface HeatmapCell {
  id: string;
  value: number;
}

interface StockStats {
  average: number;
  stddev: number;
}

export default function HeatmapPage() {
  const [data, setData] = useState<any[]>([]);
  const [timeFrame, setTimeFrame] = useState<number>(5);
  const [loading, setLoading] = useState<boolean>(false);
  const [stats, setStats] = useState<Record<string, StockStats>>({});

  useEffect(() => {
    const fetchHeatmapData = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/stock-correlation?minutes=${timeFrame}`);
        const json = await res.json();
        setData(json.heatmap);
        setStats(json.stats);
      } catch (err) {
        console.error('Failed to fetch heatmap data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchHeatmapData();
  }, [timeFrame]);

  return (
    <Box sx={{ padding: 4, backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      <Typography variant="h4" gutterBottom textAlign="center">
        🔥 Stock Correlation Heatmap
      </Typography>

      <Grid container spacing={2} justifyContent="center" alignItems="center" mb={4}>
        <Grid item>
          <FormControl fullWidth>
            <InputLabel id="time-frame-label">Time Frame</InputLabel>
            <Select
              labelId="time-frame-label"
              value={timeFrame}
              label="Time Frame"
              onChange={(e) => setTimeFrame(Number(e.target.value))}
              sx={{ width: 200 }}
            >
              <MenuItem value={5}>Last 5 minutes</MenuItem>
              <MenuItem value={10}>Last 10 minutes</MenuItem>
              <MenuItem value={30}>Last 30 minutes</MenuItem>
              <MenuItem value={60}>Last 60 minutes</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Card elevation={3} sx={{ padding: 2 }}>
        <CardContent>
          {loading ? (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
              <CircularProgress />
            </Box>
          ) : (
            <Box height={500}>
              <ResponsiveHeatMap
                data={data}
                keys={Object.keys(data?.[0] || {}).filter(k => k !== 'id')}
                indexBy="id"
                margin={{ top: 100, right: 60, bottom: 60, left: 100 }}
                axisTop={{ orient: 'top', tickSize: 5, tickPadding: 5, tickRotation: -45 }}
                axisLeft={{ orient: 'left', tickSize: 5, tickPadding: 5 }}
                colors={{ type: 'diverging', scheme: 'red_yellow_blue', divergeAt: 0.5, minValue: -1, maxValue: 1 }}
                cellOpacity={1}
                cellBorderColor={{ from: 'color', modifiers: [['darker', 0.4]] }}
                labelTextColor={{ from: 'color', modifiers: [['darker', 1.8]] }}
                tooltip={({ xKey, yKey, value }) => (
                  <MuiTooltip title={`Corr: ${value?.toFixed(2)}\n${xKey} Avg: ${stats[xKey]?.average?.toFixed(2)}, Std: ${stats[xKey]?.stddev?.toFixed(2)}`} open>
                    <Box p={1}>{`${xKey} ↔ ${yKey}: ${value?.toFixed(2)}`}</Box>
                  </MuiTooltip>
                )}
              />
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}