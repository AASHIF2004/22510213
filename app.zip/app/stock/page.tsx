'use client';

import { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  CircularProgress
} from '@mui/material';
import Grid from '@mui/material/Grid';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer
} from 'recharts';

interface StockDataPoint {
  timestamp: string;
  price: number;
  average: number;
}

export default function StockPage() {
  const [data, setData] = useState<StockDataPoint[]>([]);
  const [timeFrame, setTimeFrame] = useState<number>(5);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/stock-prices?minutes=${timeFrame}`);
        if (!res.ok) throw new Error('Failed to fetch');
        const json = await res.json();
        setData(json);
      } catch (error) {
        console.error('Error fetching stock data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [timeFrame]);

  return (
    <Box sx={{ padding: 4, backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      <Typography variant="h3" textAlign="center" gutterBottom color="primary">
        📊 Stock Price Aggregator
      </Typography>

      <Typography variant="subtitle1" textAlign="center" mb={4}>
        Visualize real-time stock trends with moving averages.
      </Typography>

      <Grid container justifyContent="center" mb={4}>
        <Grid item>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel id="time-frame-label">Time Frame</InputLabel>
            <Select
              labelId="time-frame-label"
              value={timeFrame}
              label="Time Frame"
              onChange={(e) => setTimeFrame(Number(e.target.value))}
            >
              <MenuItem value={5}>Last 5 minutes</MenuItem>
              <MenuItem value={10}>Last 10 minutes</MenuItem>
              <MenuItem value={30}>Last 30 minutes</MenuItem>
              <MenuItem value={60}>Last 60 minutes</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Card elevation={4}>
        <CardContent>
          {loading ? (
            <Box display="flex" justifyContent="center" alignItems="center" height="400px">
              <CircularProgress size={60} />
            </Box>
          ) : (
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data} margin={{ top: 20, right: 30, bottom: 10, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" tick={{ fontSize: 12 }} />
                <YAxis domain={['auto', 'auto']} tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#fff', border: '1px solid #ccc' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke="#1976d2"
                  strokeWidth={2}
                  dot={false}
                  name="Price"
                />
                <Line
                  type="monotone"
                  dataKey="average"
                  stroke="#f50057"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  name="Average"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}