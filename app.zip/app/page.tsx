
'use client';

import Link from 'next/link';
import { Box, Button, Card, CardContent, Typography, Grid } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import InsightsIcon from '@mui/icons-material/Insights';

export default function HomePage() {
  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: '#f4f6f8', padding: 4 }}>
      <Typography variant="h3" align="center" gutterBottom>
        📊 Stock Analytics Dashboard
      </Typography>
      <Typography variant="h6" align="center" mb={4} color="text.secondary">
        Get real-time stock data insights and visualize correlations interactively.
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        <Grid item xs={12} sm={6} md={4}>
          <Card sx={{ height: '100%', textAlign: 'center', padding: 2 }} elevation={4}>
            <CardContent>
              <TrendingUpIcon sx={{ fontSize: 60, color: '#1976d2' }} />
              <Typography variant="h5" gutterBottom>
                Stock Price Viewer
              </Typography>
              <Typography variant="body1" color="text.secondary" mb={2}>
                View real-time stock prices and moving averages over custom intervals.
              </Typography>
              <Link href="/stock" passHref>
                <Button variant="contained" color="primary">Go to Stock Page</Button>
              </Link>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card sx={{ height: '100%', textAlign: 'center', padding: 2 }} elevation={4}>
            <CardContent>
              <InsightsIcon sx={{ fontSize: 60, color: '#f50057' }} />
              <Typography variant="h5" gutterBottom>
                Correlation Heatmap
              </Typography>
              <Typography variant="body1" color="text.secondary" mb={2}>
                Analyze relationships between stocks using interactive heatmaps.
              </Typography>
              <Link href="/heatmap" passHref>
                <Button variant="contained" color="secondary">Go to Heatmap</Button>
              </Link>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}