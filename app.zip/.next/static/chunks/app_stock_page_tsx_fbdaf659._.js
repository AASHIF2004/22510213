(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_system_esm_d30b10b8._.js",
  "static/chunks/node_modules_@mui_material_esm_d7461571._.js",
  "static/chunks/node_modules_lodash_20634561._.js",
  "static/chunks/node_modules_recharts_es6_7bff9f4c._.js",
  "static/chunks/node_modules_4002d821._.js",
  "static/chunks/app_stock_page_tsx_1aef05eb._.js"
],
    source: "dynamic"
});
