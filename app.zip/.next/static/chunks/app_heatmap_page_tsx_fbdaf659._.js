(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_system_esm_dd56dd5a._.js",
  "static/chunks/node_modules_@mui_material_esm_4cdc6434._.js",
  "static/chunks/node_modules_@popperjs_core_lib_229f7621._.js",
  "static/chunks/node_modules_@react-spring_core_dist_react-spring_core_modern_mjs_65a81099._.js",
  "static/chunks/node_modules_lodash_b8ed2202._.js",
  "static/chunks/node_modules_d28b08d8._.js",
  "static/chunks/node_modules_@nivo_core_dist_nivo-core_mjs_4d562013._.js",
  "static/chunks/node_modules_@emotion_5f05d23f._.js",
  "static/chunks/node_modules_@nivo_8f2bf257._.js",
  "static/chunks/node_modules_2d8d67db._.js",
  "static/chunks/app_heatmap_page_tsx_d1189c2b._.js"
],
    source: "dynamic"
});
